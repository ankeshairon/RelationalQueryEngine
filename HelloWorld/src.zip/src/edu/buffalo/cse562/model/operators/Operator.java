package edu.buffalo.cse562.model.operators;

public interface Operator {


}
